/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment1;
import java.util.Scanner;

/**
 *
 * @author Thando
 */
public class Assignment1 {

    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        WardManager ward = new WardManager();

        while (true) {
            System.out.println("\n=== MEDICARE HOSPITAL - Assignment 1 ===");
            System.out.println("1. Register Patient");
            System.out.println("2. Search Patient by ID");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Delete Patient");
            System.out.println("5. Display All Registered Patients");
            System.out.println("6. Allocate Bed to Inpatient");
            System.out.println("7. Release Bed");
            System.out.println("8. Display Complete Ward Layout");
            System.out.println("9. Display Available Beds");
            System.out.println("10. Display Occupied Beds");
            System.out.println("11. Generate Reports");
            System.out.println("0. Exit");
            System.out.print("Choice: ");
            
            int choice;
            try {
                choice = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("Invalid input, enter a number.");
                continue;
            }

            switch (choice) {
                case 1 -> {
                    System.out.print("Patient ID: "); String id = sc.nextLine();
                    System.out.print("First Name: "); String fn = sc.nextLine();
                    System.out.print("Last Name: "); String ln = sc.nextLine();
                    System.out.print("Age: "); int age = Integer.parseInt(sc.nextLine());
                    System.out.print("Gender: "); String g = sc.nextLine();
                    System.out.print("Medical Condition: "); String mc = sc.nextLine();
                    System.out.print("Category (INPATIENT/OUTPATIENT/EMERGENCY): ");
                    PatientCategory cat = PatientCategory.valueOf(sc.nextLine().toUpperCase());
                    
                    Patient p;
                    p = (cat == PatientCategory.Inpatient) ?
                            new Inpatient(id, fn, ln, age, g, mc, "W1", null);
                            new Patient(id, fn, ln, age, g, mc, cat);
                            
                    if (ward.registerPatient(p)) System.out.println("Patient registered successfully!");
                    else System.out.println("Error: Patient ID already exists!");
                }

                case 2 -> {
                    System.out.print("Enter Patient ID: ");
                    Patient p = ward.searchPatient(sc.nextLine());
                    if (p != null) p.displayDetails(); else System.out.println("Patient not found");
                }
                case 3 -> {
                    System.out.print("Enter Patient ID to update: ");
                    Patient p = ward.searchPatient(sc.nextLine());
                    if (p == null) { System.out.println("Not found"); break; }
                    System.out.print("New First Name: "); p.setFirstName(sc.nextLine());
                    System.out.print("New Last Name: "); p.setLastName(sc.nextLine());
                    System.out.print("New Age: "); p.setAge(Integer.parseInt(sc.nextLine()));
                    System.out.print("New Medical Condition: "); p.setMedicalCondition(sc.nextLine());
                    System.out.println("Patient details updated!");
                }
                case 4 -> {
                    System.out.print("Enter Patient ID to delete: ");
                    if (ward.deletePatient(sc.nextLine())) System.out.println("Patient deleted!");
                    else System.out.println("Patient not found");
                }
                case 5 -> {
                    System.out.println("\n--- ALL REGISTERED PATIENTS ---");
                    ward.getAllPatients().forEach(Patient::displayDetails);
                }
                case 6 -> {
                    if (ward.isWardFull()) { System.out.println("Cannot allocate: All 20 beds are occupied!"); break; }
                    System.out.print("Patient ID (Inpatient only): "); String pid = sc.nextLine();
                    System.out.print("Bed Number (B01-B20): "); String bed = sc.nextLine();
                    if (ward.allocateBed(pid, bed)) System.out.println("Bed " + bed + " allocated to " + pid);
                    else System.out.println("Failed - Bed already occupied or patient is not an Inpatient.");
                }
                case 7 -> {
                    System.out.print("Bed Number to release: ");
                    if (ward.releaseBed(sc.nextLine())) System.out.println("Bed released!");
                    else System.out.println("Bed already empty or invalid");
                }
                case 8 -> ward.displayWardLayout();
                case 9 -> ward.displayAvailableBeds();
                case 10 -> ward.displayOccupiedBeds();
                case 11 -> {
                    ward.generateReports();
                }
                case 0 -> {
                    System.out.println("Exiting system. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice");
            }
        }
    }
}
