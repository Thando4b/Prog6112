/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment1;

/**
 *
 * @author Thando
 */
public class Bed {
    private String bedNumber;
    private boolean isOccupied;
    private String patientID;

    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.isOccupied = false;
        this.patientID = null;
    }

    public String getBedNumber() { return bedNumber; }
    public boolean isOccupied() { return isOccupied; }
    public String getPatientID() { return patientID; }

    public void allocate(String patientID) {
        this.isOccupied = true;
        this.patientID = patientID;
    }

    public void release() {
        this.isOccupied = false;
        this.patientID = null;
    }
}
    

