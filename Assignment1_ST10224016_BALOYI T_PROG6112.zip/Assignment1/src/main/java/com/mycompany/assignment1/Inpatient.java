/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment1;

/**
 *
 * @author Thando
 */
public class Inpatient {
    private String wardNumber;
    private String bedNumber;

    public Inpatient(String patientID, String firstName, String lastName, int age, String gender, String medicalCondition, String wardNumber, String bedNumber) {
        this(patientID, firstName, lastName, age, gender, medicalCondition, wardNumber, bedNumber);
    }

    public Inpatient(String patientID, String firstName, String lastName, int age, String gender, String medicalCondition, String wardNumber, String bedNumber) {
        this(patientID, firstName, lastName, age, gender, medicalCondition, wardNumber, bedNumber);
    }

    public Inpatient(String patientID, String firstName, String lastName, int age, String gender, String medicalCondition, String wardNumber, String bedNumber) {
        super(patientID, firstName, lastName, age, gender, medicalCondition, PatientCategory.Inpatient);
        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }


    Inpatient(String id, String fn, String ln, int age, String g, String mc, String w1, Object object) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    Inpatient(String id, String fn, String ln, int age, String g, String mc, String w1, Object object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getBedNumber() { return bedNumber; }
    public void setBedNumber(String bedNumber) { this.bedNumber = bedNumber; }
    public void setWardNumber(String wardNumber) { this.wardNumber = wardNumber; }

    public void displayDetails() {
        super.displayDetails();
        System.out.println(" -> Ward: " + wardNumber + " | Bed: " + bedNumber);
    }

    String getBedNumber() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}

