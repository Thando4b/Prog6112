/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment1;
import java.util.ArrayList;

/**
 *
 * @author Thando
 */
public class WardManager {
    private ArrayList<Patient> patients;
    private Bed[] beds = new Bed[20];
    private final String WARD_NUMBER = "W1";

    public WardManager() {
        patients = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            String bedId = String.format("B%02d", i+1);
            beds[i] = new Bed(bedId);
        }
    }

    // Feature 1
    public boolean registerPatient(Patient p) {
        if (searchPatient(p.getPatientID())!= null) return false; // To prevent duplicate
        patients.add(p);
        return true;
    }
    public Patient searchPatient(String id) {
        for (Patient p : patients) if (p.getPatientID().equalsIgnoreCase(id)) return p;
        return null;
    }
    public boolean deletePatient(String id) {
        Patient p = searchPatient(id);
        if (p == null) return false;
        if p instanceof Inpatient inpatient) releaseBed(inpatient.getBedNumber());
        return patients.remove(p);
    }
    public ArrayList<Patient> getAllPatients() { return patients; }

    // Feature 2
    public boolean allocateBed(String patientID, String bedNumber) {
        Patient p = searchPatient(patientID);
        if (p == null || p.getCategory()!= PatientCategory.Inpatient) return false;

        for (Bed bed : beds) {
            if (bed.getBedNumber().equalsIgnoreCase(bedNumber)) {
                if (bed.isOccupied()) return false; // Avoid allocating occupied bed
                // If patient already has a bed, release old one
                if (p instanceof Inpatient && ((Inpatient)p).getBedNumber()!= null) {
                    releaseBed(((Inpatient)p).getBedNumber());
                }
                bed.allocate(patientID);
                // Update patient object to Inpatient if needed
                if (!(p instanceof Inpatient)) {
                    // Convert base patient to inpatient - remove and add new
                    patients.remove(p);
                    Inpatient ip = new Inpatient(p.patientID, p.firstName, p.lastName, p.age, p.gender, p.medicalCondition, WARD_NUMBER, bedNumber);
                    patients.add(ip);
                } else {
                    ((Inpatient)p).setBedNumber(bedNumber);
                    ((Inpatient)p).setWardNumber(WARD_NUMBER);
                }
                return true;
            }
        }
        return false;
    }

    public boolean releaseBed(String bedNumber) {
        for (Bed bed : beds) {
            if (bed.getBedNumber().equalsIgnoreCase(bedNumber) && bed.isOccupied()) {
                bed.release();
                return true;
            }
        }
        return false;
    }

    public void displayWardLayout() {
        System.out.println("\n--- WARD LAYOUT (4x5) ---");
        for (int i = 0; i < 20; i++) {
            String status = beds[i].isOccupied()? "[X]" : "[ ]";
            System.out.print(beds[i].getBedNumber() + status + "\t");
            if ((i+1) % 5 == 0) System.out.println();
        }
    }

    public void displayAvailableBeds() {
        System.out.println("\nAvailable Beds:");
        for (Bed b : beds) if (!b.isOccupied()) System.out.print(b.getBedNumber() + " ");
        System.out.println();
    }

    public void displayOccupiedBeds() {
        System.out.println("\nOccupied Beds:");
        for (Bed b : beds) if (b.isOccupied()) System.out.println(b.getBedNumber() + " -> Patient " + b.getPatientID());
    }

    // Feature 3 Reports
    public void generateReports() {
        System.out.println("\n--- WARD REPORT ---");
        System.out.println("Total Registered Patients: " + patients.size());
        long occupied = java.util.Arrays.stream(beds).filter(Bed::isOccupied).count();
        System.out.println("Total Occupied Beds: " + occupied);
        System.out.println("Total Available Beds: " + (20 - occupied));
        double occupancy = (occupied / 20.0) * 100;
        System.out.printf("Ward Occupancy: %.2f%%\n", occupancy);
    }

    public boolean isWardFull() {
        for (Bed b : beds) if (!b.isOccupied()) return false;
        return true;
    }
}

