/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package WardManagerTest;

/**
 *
 * @author Thando
 */
class PatientCategory {

    static com.mycompany.assignment1.PatientCategory OUTPATIENT;
    static com.mycompany.assignment1.PatientCategory EMERGENCY;
    
}
