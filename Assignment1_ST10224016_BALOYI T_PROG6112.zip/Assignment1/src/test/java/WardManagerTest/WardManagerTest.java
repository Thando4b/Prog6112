/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package WardManagerTest;

import com.mycompany.assignment1.Inpatient;
import com.mycompany.assignment1.Patient;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Thando
 */
    public class WardManagerTest {
    @Test public void testRegisterAndSearch() {
        WardManagerTest w = new WardManagerTest();
        Patient p = new Patient("P001", "Thando", "Mikateko", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        assertTrue(w.registerPatient(p));
        assertNotNull(w.searchPatient("P001"));
    }
    @Test public void testDuplicateID() {
        WardManagerTest w = new WardManagerTest();
        w.registerPatient(new Patient("P001", "A", "B", 20, "M", "Cold", PatientCategory.EMERGENCY));
        assertFalse(w.registerPatient(new Patient("P001", "C", "D", 25, "F", "Fever", PatientCategory.EMERGENCY)));
    }
    @Test public void testAllocateAndPreventOccupied() {
        WardManagerTest w = new WardManagerTest();
        w.registerPatient(new Inpatient("P002", "Ntsako", "MI", 40, "Female", "Surgery", "W1", null));
        assertTrue(w.allocateBed("P002", "B01"));
        w.registerPatient(new Inpatient("P003", "Mpho", "Tinyiko", 50, "Male", "Fracture", "W1", null));
        assertFalse(w.allocateBed("P003", "B01")); // prevent allocating occupied
    }
    @Test public void testWardFull() {
        WardManagerTest w = new WardManagerTest();
        for (int i = 1; i <= 20; i++) {
            String id = String.format("P%03d", i);
            w.registerPatient(new Inpatient(id, "F", "L", 20, "M", "Test", "W1", null));
            w.allocateBed(id, String.format("B%02d", i));
        }
        w.registerPatient(new Inpatient("P021", "Extra", "Patient", 20, "M", "Test", "W1", null));
        assertFalse(w.allocateBed("P021", "B01"));
        assertTrue(w.isWardFull());
    }

    private boolean registerPatient(Patient p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Object searchPatient(String p001) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean isWardFull() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean allocateBed(String p021, String b01) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    
 
    
   

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

